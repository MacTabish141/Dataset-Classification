1)Used stacking classifier on SDSS17 dataset

2)Stacking classifier consist of knn, decision tree and Random Forest with 
  logistic regression as final estimator